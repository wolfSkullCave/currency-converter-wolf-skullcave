# SPDX-FileCopyrightText: 2025-present wolf_skullcave-Laptop <7805222+wolfSkullCave@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0a1"
